package com.darkgpt.flutuante;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

public class OverlayService extends Service {
    private WindowManager wm;
    private View bubble, panel;
    private WindowManager.LayoutParams bubbleParams, panelParams;
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onCreate() {
        super.onCreate();
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        int type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;

        TextView coin = new TextView(this);
        coin.setText("🪙");
        coin.setTextSize(27);
        coin.setGravity(Gravity.CENTER);
        coin.setBackground(makeCircle());
        bubble = coin;
        bubbleParams = new WindowManager.LayoutParams(dp(60), dp(60), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        bubbleParams.gravity = Gravity.TOP | Gravity.START;
        bubbleParams.x = dp(8);
        bubbleParams.y = dp(220);
        wm.addView(bubble, bubbleParams);

        bubble.setOnClickListener(v -> togglePanel());
        bubble.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY; int startX, startY; boolean moved;
            public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    downX=e.getRawX(); downY=e.getRawY(); startX=bubbleParams.x; startY=bubbleParams.y; moved=false; return false;
                } else if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    float dx=e.getRawX()-downX, dy=e.getRawY()-downY;
                    if (Math.abs(dx)>dp(5)||Math.abs(dy)>dp(5)) moved=true;
                    if (moved) { bubbleParams.x=startX+(int)dx; bubbleParams.y=startY+(int)dy; wm.updateViewLayout(bubble,bubbleParams); return true; }
                }
                return false;
            }
        });
    }

    private android.graphics.drawable.GradientDrawable makeCircle() {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        d.setColor(0xFF9B6B16);
        d.setStroke(dp(2), 0xFFFFD66B);
        return d;
    }

    private void togglePanel() {
        if (panel != null) { try { wm.removeView(panel); } catch(Exception ignored) {} panel=null; return; }
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16),dp(14),dp(16),dp(14));
        box.setBackgroundColor(0xF022201E);

        TextView head = text("DARKGPT • ANÁLISE", 18, 0xFFFFD66B, true);
        box.addView(head);
        box.addView(text("Leitura manual dos resultados", 14, 0xFFE8E2D9, false));
        box.addView(text("• The Great Icescape: -10,84", 15, 0xFFFF655B, true));
        box.addView(text("• Dragon Hatch: -29,45", 15, 0xFFFF655B, true));
        box.addView(text("• Dragon Hatch 2: -1,16", 15, 0xFFFF655B, true));
        box.addView(text("Aviso: os dados são exemplos das capturas enviadas. Não são atualizados automaticamente e não preveem a próxima rodada.", 13, 0xFFD0C8BC, false));
        TextView close = text("Fechar painel", 15, 0xFFFFD66B, true);
        close.setGravity(Gravity.CENTER);
        close.setPadding(0,dp(12),0,0);
        box.addView(close);
        close.setOnClickListener(v -> { if(panel!=null){wm.removeView(panel);panel=null;} });

        panel = box;
        panelParams = new WindowManager.LayoutParams(dp(300), -2,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        panelParams.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        panelParams.y = dp(120);
        wm.addView(panel,panelParams);
    }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setPadding(0,dp(5),0,dp(5));
        if(bold)t.setTypeface(null, Typeface.BOLD);
        return t;
    }

    @Override public int onStartCommand(Intent i, int flags, int id) { return START_STICKY; }
    @Override public void onDestroy() {
        try { if(panel!=null) wm.removeView(panel); } catch(Exception ignored) {}
        try { if(bubble!=null) wm.removeView(bubble); } catch(Exception ignored) {}
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent i) { return null; }
}
