package com.darkgpt.flutuante;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(24), dp(24), dp(24), dp(24));
        root.setBackgroundColor(0xFF171513);

        TextView title = new TextView(this);
        title.setText("🪙 DarkGPT Flutuante");
        title.setTextColor(0xFFFFD66B);
        title.setTextSize(25);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(70)));

        TextView desc = new TextView(this);
        desc.setText("Bolinha dourada sobre outros apps e painel de análise de resultados. Esta versão é uma demonstração: não lê automaticamente a tela nem prevê resultados.");
        desc.setTextColor(0xFFE8E2D9);
        desc.setTextSize(16);
        desc.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams descLp = new LinearLayout.LayoutParams(-1, -2);
        descLp.setMargins(0, dp(8), 0, dp(24));
        root.addView(desc, descLp);

        Button grant = new Button(this);
        grant.setText("Permitir exibição sobre outros apps");
        root.addView(grant, new LinearLayout.LayoutParams(-1, -2));
        grant.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } else startOverlay();
        });

        Button start = new Button(this);
        start.setText("Iniciar bolinha flutuante");
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-1, -2);
        slp.setMargins(0, dp(12), 0, 0);
        root.addView(start, slp);
        start.setOnClickListener(v -> {
            if (Settings.canDrawOverlays(this)) startOverlay();
            else {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
                startActivity(i);
            }
        });

        setContentView(root);
    }

    private void startOverlay() {
        if (Settings.canDrawOverlays(this)) {
            startService(new Intent(this, OverlayService.class));
            finish();
        }
    }

    @Override protected void onResume() {
        super.onResume();
    }
}
