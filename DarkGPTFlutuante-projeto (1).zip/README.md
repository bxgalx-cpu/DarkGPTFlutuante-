# DarkGPT Flutuante — projeto inicial Android

Este é um projeto-fonte Android Studio para uma bolinha dourada sobre outros apps, com painel flutuante.

## Limitações importantes
- Este pacote contém o código-fonte, não um APK já compilado.
- O painel usa valores de demonstração das capturas fornecidas.
- Ainda não faz OCR/leitura automática da tela, não acompanha rodadas em tempo real e não prevê ganhos ou perdas.
- Para leitura automática seria necessário implementar e testar captura de tela/OCR com consentimento explícito do usuário e permissões adequadas.

## Como compilar
1. Abra a pasta no Android Studio atualizado.
2. Aguarde a sincronização do Gradle.
3. Use Build > Build APK(s).
4. No Android, instale o APK gerado e permita "Exibir sobre outros apps".
5. Abra o app e toque em "Iniciar bolinha flutuante".

Aplicativo de demonstração. Não altera saldo nem interage com apostas.
